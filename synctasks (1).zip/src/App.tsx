import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LayoutDashboard, NotebookTabs, Settings, Plus, CheckCircle2, Circle, Clock, Star, Search, CalendarDays, ChevronLeft, ChevronRight, X, Hash, Folder, AlignLeft, MapPin, Timer, Play, Pause, RotateCcw, Bell } from 'lucide-react';

// --- Types ---
type View = 'dashboard' | 'calendar' | 'focus' | 'notes' | 'settings';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
  important: boolean;
  dueDate?: string;
  folder?: string;
  tags?: string[];
  notes?: string;
}

interface Note {
  id: string;
  title: string;
  content: string;
  updatedAt: string;
  tags?: string[];
  color?: string;
}

interface CalendarEvent {
  id: string;
  title: string;
  time: string;
  date: string;
  location?: string;
  type: 'work' | 'personal' | 'social';
  tags?: string[];
  notes?: string;
}

// --- Components ---

const Dashboard = ({ todos, onOpenCreate, onOpenEventCreate, events }: { 
  todos: Todo[], 
  onOpenCreate: () => void, 
  onOpenEventCreate: () => void,
  events: CalendarEvent[]
}) => {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center px-4 pt-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">SyncTasks</h1>
          <p className="text-muted-foreground text-sm">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <div className="flex gap-2">
           <button 
            onClick={onOpenEventCreate}
            className="h-10 px-4 rounded-full bg-zinc-100 text-zinc-900 flex items-center justify-center gap-2 hover:scale-105 transition-transform active:scale-95 text-xs font-bold"
          >
            <CalendarDays size={18} />
            Event
          </button>
          <button 
            onClick={onOpenCreate}
            className="h-10 w-10 rounded-full bg-black text-white flex items-center justify-center hover:scale-105 transition-transform active:scale-95 shadow-xl"
          >
            <Plus size={24} />
          </button>
        </div>
      </header>

      {/* Event Widget */}
      <div className="px-4">
        <div className="bg-gradient-to-br from-zinc-900 to-zinc-800 rounded-[2rem] p-6 shadow-xl text-white relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
            <CalendarDays size={120} />
          </div>
          <div className="relative z-10">
            <h3 className="text-lg font-bold mb-1">Upcoming Events</h3>
            <p className="text-zinc-400 text-xs mb-4">You have {events.length} events scheduled for this week.</p>
            
            <div className="space-y-3">
              {events.slice(0, 2).map(event => (
                <div key={event.id} className="flex items-center gap-3 bg-white/5 p-3 rounded-2xl border border-white/10">
                  <div className={`w-1 h-8 rounded-full ${event.type === 'work' ? 'bg-blue-400' : event.type === 'social' ? 'bg-purple-400' : 'bg-teal-400'}`} />
                  <div>
                    <p className="text-[13px] font-semibold">{event.title}</p>
                    <p className="text-[10px] text-zinc-400 font-medium">{event.time} • {event.date}</p>
                  </div>
                </div>
              ))}
            </div>

            <button 
              onClick={onOpenEventCreate}
              className="mt-4 w-full bg-white text-black py-3 rounded-xl text-xs font-bold hover:bg-zinc-100 transition-colors"
            >
              Add New Event
            </button>
          </div>
        </div>
      </div>

      <div className="px-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input 
            type="text" 
            placeholder="Search tasks..." 
            className="w-full bg-secondary/50 rounded-2xl py-3 pl-10 pr-4 outline-none focus:ring-2 ring-black/5"
          />
        </div>
      </div>

      <div className="px-4 space-y-3">
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Active Tasks</h2>
        <div className="space-y-2 pb-20">
          {todos.map((todo) => (
            <motion.div 
              key={todo.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col bg-white p-4 rounded-2xl border border-black/5 shadow-sm"
            >
              <div className="flex items-center gap-3">
                <button className={`${todo.completed ? 'text-green-500' : 'text-zinc-300'}`}>
                  {todo.completed ? <CheckCircle2 size={22} /> : <Circle size={22} />}
                </button>
                <div className="flex-1">
                  <p className={`text-[15px] font-medium ${todo.completed ? 'line-through text-muted-foreground' : 'text-zinc-800'}`}>
                    {todo.text}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    {todo.dueDate && (
                      <div className="flex items-center gap-1">
                        <Clock size={10} className="text-zinc-400" />
                        <span className="text-[10px] text-zinc-400">{todo.dueDate}</span>
                      </div>
                    )}
                    {todo.folder && (
                      <div className="flex items-center gap-1 bg-zinc-50 px-1.5 py-0.5 rounded-md border border-zinc-100">
                        <Folder size={10} className="text-zinc-400" />
                        <span className="text-[10px] font-medium text-zinc-500">{todo.folder}</span>
                      </div>
                    )}
                  </div>
                </div>
                {todo.important && <Star size={16} className="fill-amber-400 text-amber-400" />}
              </div>
              
              {todo.tags && todo.tags.length > 0 && (
                <div className="flex gap-1.5 mt-2 ml-9">
                  {todo.tags.map(tag => (
                    <span key={tag} className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {todo.notes && (
                <p className="text-[11px] text-zinc-400 mt-2 ml-9 line-clamp-1 italic">
                  {todo.notes}
                </p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

const CreateTaskModal = ({ isOpen, onClose, onCreate }: { isOpen: boolean, onClose: () => void, onCreate: (todo: Partial<Todo>) => void }) => {
  const [text, setText] = useState('');
  const [folder, setFolder] = useState('Personal');
  const [notes, setNotes] = useState('');
  const [important, setImportant] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');

  const handleAddTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag]);
      setNewTag('');
    }
  };

  const handleSubmit = () => {
    if (!text.trim()) return;
    onCreate({
      text,
      folder,
      notes,
      important,
      tags,
      dueDate: 'Today',
      completed: false
    });
    // Reset
    setText('');
    setFolder('Personal');
    setNotes('');
    setTags([]);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
          />
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-white rounded-t-[2.5rem] px-6 pt-8 pb-10 max-w-md mx-auto shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold tracking-tight">Create Task</h2>
              <button onClick={onClose} className="p-2 bg-zinc-100 rounded-full text-zinc-500">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Task Name</label>
                <input 
                  autoFocus
                  type="text" 
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="What needs to be done?"
                  className="w-full bg-zinc-50 rounded-2xl p-4 border border-zinc-100 outline-none focus:ring-2 focus:ring-black/5 text-[15px] font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Folder</label>
                  <div className="relative">
                    <Folder className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                    <select 
                      value={folder}
                      onChange={(e) => setFolder(e.target.value)}
                      className="w-full bg-zinc-50 rounded-2xl py-4 pl-11 pr-4 border border-zinc-100 outline-none appearance-none text-[14px]"
                    >
                      <option>Personal</option>
                      <option>Work</option>
                      <option>Ideas</option>
                      <option>Shopping</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2 flex flex-col">
                  <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Priority</label>
                  <button 
                    onClick={() => setImportant(!important)}
                    className={`flex items-center gap-2 h-[58px] rounded-2xl px-4 border transition-all ${important ? 'bg-amber-50 border-amber-200 text-amber-600' : 'bg-zinc-50 border-zinc-100 text-zinc-400'}`}
                  >
                    <Star size={16} className={important ? 'fill-amber-400' : ''} />
                    <span className="text-[14px] font-medium">{important ? 'Important' : 'Normal'}</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Tags</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {tags.map(tag => (
                    <span key={tag} className="bg-zinc-100 text-zinc-600 px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                      {tag}
                      <button onClick={() => setTags(tags.filter(t => t !== tag))}><X size={10} /></button>
                    </span>
                  ))}
                </div>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                  <input 
                    type="text" 
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                    placeholder="Add a label..."
                    className="w-full bg-zinc-50 rounded-2xl py-4 pl-11 pr-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Notes</label>
                <div className="relative">
                  <AlignLeft className="absolute left-4 top-4 text-zinc-400" size={16} />
                  <textarea 
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Add details, links, or sub-tasks..."
                    className="w-full bg-zinc-50 rounded-2xl p-4 pl-11 border border-zinc-100 outline-none h-24 text-[14px] resize-none"
                  />
                </div>
              </div>

              <button 
                onClick={handleSubmit}
                className="w-full bg-black text-white rounded-2xl py-5 font-bold tracking-tight shadow-xl active:scale-[0.98] transition-transform mt-4"
              >
                Create Task
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

const Calendar = ({ events, onOpenEventCreate, selectedDate, setSelectedDate }: { events: CalendarEvent[], onOpenEventCreate: () => void, selectedDate: Date, setSelectedDate: (d: Date) => void }) => {
  const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  
  const [currentDate, setCurrentDate] = useState(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1));

  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Calendar Helpers
  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const prevMonth = () => setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentYear, currentMonth + 1, 1));

  const totalDays = getDaysInMonth(currentYear, currentMonth);
  const startDay = getFirstDayOfMonth(currentYear, currentMonth);

  // Pad the grid with empty slots for the previous month
  const gridDays = [...Array(startDay).fill(null), ...Array(totalDays).keys()];

  const formatDateKey = (day: number) => {
    const d = new Date(currentYear, currentMonth, day);
    return d.toISOString().split('T')[0];
  };

  const isSelected = (day: number) => {
    return selectedDate.getDate() === day && selectedDate.getMonth() === currentMonth && selectedDate.getFullYear() === currentYear;
  };

  const isToday = (day: number) => {
    const today = new Date();
    return today.getDate() === day && today.getMonth() === currentMonth && today.getFullYear() === currentYear;
  };

  const hasEventOnDay = (day: number) => {
    const dateStr = formatDateKey(day);
    return events.some(e => e.date === dateStr);
  };

  const selectedDateStr = selectedDate.toISOString().split('T')[0];
  const filteredEvents = events.filter(e => e.date === selectedDateStr);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center px-4 pt-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Calendar</h1>
          <p className="text-muted-foreground text-sm font-medium">{monthNames[currentMonth]} {currentYear}</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={prevMonth}
            className="h-10 w-10 rounded-full border border-black/5 bg-white flex items-center justify-center hover:bg-zinc-50 active:scale-95 transition-all"
          >
            <ChevronLeft size={20} />
          </button>
          <button 
            onClick={nextMonth}
            className="h-10 w-10 rounded-full border border-black/5 bg-white flex items-center justify-center hover:bg-zinc-50 active:scale-95 transition-all"
          >
            <ChevronRight size={20} />
          </button>
          <button 
            onClick={onOpenEventCreate}
            className="h-10 w-10 rounded-full bg-black text-white flex items-center justify-center hover:scale-105 transition-transform active:scale-95 shadow-xl ml-2"
          >
            <Plus size={20} />
          </button>
        </div>
      </header>

      {/* Modern Calendar Grid */}
      <div className="px-4">
        <div className="bg-white rounded-[2rem] border border-black/5 p-6 shadow-sm">
          <div className="grid grid-cols-7 mb-4">
            {days.map((day, i) => (
              <div key={i} className="text-center text-[10px] font-bold text-zinc-400 tracking-widest pb-2 uppercase">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-y-2">
            {gridDays.map((val, i) => {
              if (val === null) return <div key={`empty-${i}`} />;
              const day = val + 1;
              const active = isSelected(day);
              const today = isToday(day);
              const dot = hasEventOnDay(day);
              
              return (
                <div key={i} className="relative flex flex-col items-center py-2">
                  <button 
                    onClick={() => setSelectedDate(new Date(currentYear, currentMonth, day))}
                    className={`h-9 w-9 rounded-full flex items-center justify-center text-[13px] font-semibold transition-all
                      ${active ? 'bg-black text-white shadow-lg scale-110 z-10' : today ? 'bg-zinc-100 text-black' : 'text-zinc-600 hover:bg-zinc-100'}
                    `}
                  >
                    {day}
                  </button>
                  {dot && (
                    <div className={`absolute bottom-1 w-1 h-1 rounded-full ${active ? 'bg-white' : 'bg-zinc-300'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Daily Timeline */}
      <div className="px-4 space-y-4 pb-12">
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">
          {selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} Events
        </h2>
        
        {filteredEvents.length > 0 ? (
          <div className="space-y-3">
            {filteredEvents.map((event) => (
              <motion.div 
                key={event.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex gap-4 items-start"
              >
                <div className="w-16 pt-1 text-right">
                  <span className="text-[10px] font-bold text-zinc-400 tabular-nums">{event.time}</span>
                </div>
                <div className={`flex-1 p-4 rounded-2xl border-l-4 shadow-sm bg-white border-black/5
                  ${event.type === 'work' ? 'border-l-blue-400' : event.type === 'social' ? 'border-l-purple-400' : 'border-l-teal-400'}
                `}>
                  <h4 className="font-semibold text-sm">{event.title}</h4>
                  <p className="text-[10px] uppercase tracking-wider text-zinc-400 mt-0.5">{event.type} {event.location && `• ${event.location}`}</p>
                  {event.tags && event.tags.length > 0 && (
                    <div className="flex gap-1.5 mt-2">
                      {event.tags.map(tag => (
                        <span key={tag} className="text-[8px] font-bold uppercase tracking-widest text-zinc-300">#{tag}</span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="py-12 flex flex-col items-center justify-center text-zinc-300 space-y-2">
            <div className="p-4 bg-zinc-50 rounded-full">
              <CalendarDays size={32} strokeWidth={1.5} />
            </div>
            <p className="text-xs font-medium">No events for this day</p>
          </div>
        )}
      </div>
    </div>
  );
};

const CreateEventModal = ({ isOpen, onClose, onCreate, initialDate }: { isOpen: boolean, onClose: () => void, onCreate: (event: Partial<CalendarEvent>) => void, initialDate?: string }) => {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(initialDate || new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('10:00 AM');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<CalendarEvent['type']>('work');
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');

  // Update date if initialDate changes
  React.useEffect(() => {
    if (initialDate) setDate(initialDate);
  }, [initialDate, isOpen]);

  const handleAddTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag]);
      setNewTag('');
    }
  };

  const handleSubmit = () => {
    if (!title.trim()) return;
    onCreate({
      title,
      date,
      time,
      location,
      type,
      notes,
      tags
    });
    // Reset
    setTitle('');
    setLocation('');
    setNotes('');
    setTags([]);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
          />
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-white rounded-t-[2.5rem] px-6 pt-8 pb-10 max-w-md mx-auto shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold tracking-tight">Schedule Event</h2>
              <button onClick={onClose} className="p-2 bg-zinc-100 rounded-full text-zinc-500">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Event Title</label>
                <input 
                  autoFocus
                  type="text" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Kickoff meeting, Dinner..."
                  className="w-full bg-zinc-50 rounded-2xl p-4 border border-zinc-100 outline-none focus:ring-2 focus:ring-black/5 text-[15px] font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Date</label>
                  <input 
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-zinc-50 rounded-2xl p-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Time</label>
                  <input 
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    placeholder="10:00 AM"
                    className="w-full bg-zinc-50 rounded-2xl p-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                  <input 
                    type="text" 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Meeting Room, Cafe, Home..."
                    className="w-full bg-zinc-50 rounded-2xl py-4 pl-11 pr-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Category</label>
                <div className="flex gap-2">
                  {(['work', 'social', 'personal'] as const).map(t => (
                    <button
                      key={t}
                      onClick={() => setType(t)}
                      className={`flex-1 py-3 rounded-xl text-xs font-bold uppercase tracking-widest border transition-all ${type === t ? 'bg-black text-white border-black' : 'bg-zinc-50 border-zinc-100 text-zinc-400'}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Tags</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {tags.map(tag => (
                    <span key={tag} className="bg-zinc-100 text-zinc-600 px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                      {tag}
                      <button onClick={() => setTags(tags.filter(t => t !== tag))}><X size={10} /></button>
                    </span>
                  ))}
                </div>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                  <input 
                    type="text" 
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                    placeholder="Add a label..."
                    className="w-full bg-zinc-50 rounded-2xl py-4 pl-11 pr-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Notes</label>
                <div className="relative">
                  <AlignLeft className="absolute left-4 top-4 text-zinc-400" size={16} />
                  <textarea 
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Anything else to remember?"
                    className="w-full bg-zinc-50 rounded-2xl p-4 pl-11 border border-zinc-100 outline-none h-24 text-[14px] resize-none"
                  />
                </div>
              </div>

              <button 
                onClick={handleSubmit}
                className="w-full bg-black text-white rounded-2xl py-5 font-bold tracking-tight shadow-xl active:scale-[0.98] transition-transform mt-4"
              >
                Schedule Event
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

const FocusTimer = () => {
  const [seconds, setSeconds] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [customMinutes, setCustomMinutes] = useState('25');
  const [showNotification, setShowNotification] = useState(false);

  React.useEffect(() => {
    let interval: any = null;
    if (isActive && seconds > 0) {
      interval = setInterval(() => {
        setSeconds((s) => s - 1);
      }, 1000);
    } else if (seconds === 0) {
      setIsActive(false);
      setShowNotification(true);
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(200);
      }
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  const toggle = () => setIsActive(!isActive);
  const reset = () => {
    setIsActive(false);
    setSeconds(parseInt(customMinutes) * 60);
    setShowNotification(false);
  };

  const setCustomTime = (mins: string) => {
    setCustomMinutes(mins);
    const m = parseInt(mins);
    if (!isNaN(m)) {
      setSeconds(m * 60);
      setIsActive(false);
    }
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = (seconds / (parseInt(customMinutes) * 60 || 1)) * 100;

  return (
    <div className="space-y-8 px-4 pt-8">
      <header className="text-center space-y-1">
        <h1 className="text-3xl font-semibold tracking-tight">Focus Timer</h1>
        <p className="text-muted-foreground text-sm">Stay productive, stay focused.</p>
      </header>

      <div className="relative flex flex-col items-center justify-center py-10">
        {/* Progress Ring */}
        <div className="relative w-72 h-72 flex items-center justify-center">
          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              className="text-zinc-100 stroke-current"
              strokeWidth="4"
              cx="50"
              cy="50"
              r="45"
              fill="transparent"
            />
            <motion.circle
              className="text-black stroke-current"
              strokeWidth="4"
              strokeLinecap="round"
              cx="50"
              cy="50"
              r="45"
              fill="transparent"
              initial={{ strokeDasharray: "283 283", strokeDashoffset: 0 }}
              animate={{ strokeDashoffset: 283 - (283 * progress) / 100 }}
              transition={{ duration: 0.5, ease: "linear" }}
            />
          </svg>
          <div className="text-center z-10">
            <span className="text-6xl font-light tracking-tighter tabular-nums">{formatTime(seconds)}</span>
            <div className="flex items-center justify-center gap-1 mt-2 text-muted-foreground uppercase tracking-widest text-[10px] font-bold">
              <Timer size={14} />
              Minutes
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-4">
        <button 
          onClick={reset}
          className="p-5 rounded-full bg-zinc-100 text-zinc-600 hover:bg-zinc-200 transition-colors"
        >
          <RotateCcw size={24} />
        </button>
        <button 
          onClick={toggle}
          className={`h-20 w-20 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-95 ${isActive ? 'bg-zinc-100 text-black' : 'bg-black text-white'}`}
        >
          {isActive ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
        </button>
        <div className="p-5 w-14" /> {/* Spacer for symmetry */}
      </div>

      <div className="space-y-4">
        <h2 className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 px-1">Presets & Custom</h2>
        <div className="grid grid-cols-4 gap-3">
          {['15', '25', '45'].map((min) => (
            <button
              key={min}
              onClick={() => setCustomTime(min)}
              className={`py-3 rounded-2xl text-sm font-bold border transition-all ${customMinutes === min ? 'bg-black text-white border-black' : 'bg-white border-black/5 text-zinc-500'}`}
            >
              {min}m
            </button>
          ))}
          <div className="relative">
            <input 
              type="number"
              value={customMinutes}
              onChange={(e) => setCustomTime(e.target.value)}
              className="w-full bg-white border border-black/5 rounded-2xl py-3 px-3 text-sm font-bold text-center outline-none focus:ring-2 ring-black/5"
              placeholder="Min"
            />
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      <AnimatePresence>
        {showNotification && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed top-8 left-4 right-4 z-[100] max-w-md mx-auto"
          >
            <div className="bg-black text-white p-4 rounded-2xl shadow-2xl flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center animate-bounce">
                <Bell size={20} />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-sm">Time's up!</h4>
                <p className="text-xs text-zinc-400">Your focus session has completed.</p>
              </div>
              <button 
                onClick={() => setShowNotification(false)}
                className="bg-white/10 px-4 py-2 rounded-xl text-xs font-bold"
              >
                Dismiss
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Notes = ({ notes, onOpenCreate }: { notes: Note[], onOpenCreate: () => void }) => {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center px-4 pt-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Notes</h1>
          <p className="text-muted-foreground text-sm">Organize your thoughts</p>
        </div>
        <button 
          onClick={onOpenCreate}
          className="h-10 w-10 rounded-full bg-black text-white flex items-center justify-center hover:scale-105 transition-transform active:scale-95 shadow-xl"
        >
          <Plus size={24} />
        </button>
      </header>
      
      <div className="px-4 grid grid-cols-2 gap-3 pb-24">
        {notes.map((note) => (
          <motion.div 
            key={note.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`p-4 rounded-[2rem] border border-black/5 shadow-sm space-y-2 h-44 flex flex-col transition-all hover:shadow-md ${note.color || 'bg-white'}`}
          >
            <h3 className="font-bold text-[15px] line-clamp-1 text-zinc-800">{note.title}</h3>
            <p className="text-xs text-zinc-500 line-clamp-4 leading-relaxed flex-1">
              {note.content}
            </p>
            
            {note.tags && note.tags.length > 0 && (
              <div className="flex gap-1 overflow-hidden">
                {note.tags.slice(0, 2).map(tag => (
                  <span key={tag} className="text-[8px] font-bold uppercase tracking-widest text-zinc-400 bg-black/5 px-1.5 py-0.5 rounded">#{tag}</span>
                ))}
              </div>
            )}

            <div className="flex justify-between items-center mt-auto pt-2">
              <span className="text-[9px] uppercase font-bold tracking-widest text-zinc-300">
                {note.updatedAt}
              </span>
            </div>
          </motion.div>
        ))}
        <button 
          onClick={onOpenCreate}
          className="p-4 rounded-[2rem] border-2 border-dashed border-zinc-200 flex items-center justify-center h-44 hover:bg-zinc-50 transition-colors group"
        >
          <div className="text-zinc-400 flex flex-col items-center group-hover:scale-110 transition-transform">
            <Plus size={24} />
            <span className="text-xs font-medium mt-1">New Note</span>
          </div>
        </button>
      </div>
    </div>
  );
};

const CreateNoteModal = ({ isOpen, onClose, onCreate }: { isOpen: boolean, onClose: () => void, onCreate: (note: Partial<Note>) => void }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState('bg-white');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');

  const colors = [
    { name: 'White', class: 'bg-white' },
    { name: 'Yellow', class: 'bg-amber-50' },
    { name: 'Blue', class: 'bg-blue-50' },
    { name: 'Green', class: 'bg-emerald-50' },
    { name: 'Purple', class: 'bg-purple-50' },
    { name: 'Rose', class: 'bg-rose-50' },
  ];

  const handleAddTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag]);
      setNewTag('');
    }
  };

  const handleSubmit = () => {
    if (!title.trim() && !content.trim()) return;
    onCreate({
      title: title || 'Untitled Note',
      content,
      color,
      tags,
      updatedAt: 'Just now'
    });
    // Reset
    setTitle('');
    setContent('');
    setColor('bg-white');
    setTags([]);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
          />
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 z-[70] bg-white rounded-t-[2.5rem] px-6 pt-8 pb-10 max-w-md mx-auto shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold tracking-tight">New Note</h2>
              <button onClick={onClose} className="p-2 bg-zinc-100 rounded-full text-zinc-500">
                <X size={20} />
              </button>
            </div>

            <div className={`p-6 rounded-[2rem] border border-black/5 mb-6 transition-colors ${color}`}>
              <input 
                autoFocus
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Note Title"
                className="w-full bg-transparent border-none outline-none text-lg font-bold placeholder:text-zinc-300"
              />
              <textarea 
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Start typing your thoughts..."
                className="w-full bg-transparent border-none outline-none mt-2 h-32 resize-none text-sm leading-relaxed placeholder:text-zinc-300"
              />
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Card Color</label>
                <div className="flex justify-between px-1">
                  {colors.map((c) => (
                    <button
                      key={c.class}
                      onClick={() => setColor(c.class)}
                      className={`h-10 w-10 rounded-full border-2 transition-all ${c.class} ${color === c.class ? 'border-black scale-110 shadow-md' : 'border-black/5'}`}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 ml-1">Tags</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {tags.map(tag => (
                    <span key={tag} className="bg-zinc-100 text-zinc-600 px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                      {tag}
                      <button onClick={() => setTags(tags.filter(t => t !== tag))}><X size={10} /></button>
                    </span>
                  ))}
                </div>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                  <input 
                    type="text" 
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                    placeholder="Add a tag..."
                    className="w-full bg-zinc-50 rounded-2xl py-4 pl-11 pr-4 border border-zinc-100 outline-none text-[14px]"
                  />
                </div>
              </div>

              <button 
                onClick={handleSubmit}
                className="w-full bg-black text-white rounded-2xl py-5 font-bold tracking-tight shadow-xl active:scale-[0.98] transition-transform mt-4"
              >
                Save Note
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

const SettingsView = () => {
  const sections = [
    { title: 'Account', items: ['Profile', 'Privacy', 'Security'] },
    { title: 'Appearance', items: ['Theme', 'Typography', 'App Icon'] },
    { title: 'Help & Support', items: ['FAQ', 'Contact Us', 'Terms of Service'] },
  ];

  return (
    <div className="space-y-6">
      <header className="px-4 pt-8 border-b border-black/5 pb-4">
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
      </header>

      <div className="px-4 space-y-8">
        {sections.map((section) => (
          <div key={section.title} className="space-y-3">
            <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-zinc-400 px-1">
              {section.title}
            </h2>
            <div className="bg-white rounded-3xl overflow-hidden border border-black/5 shadow-sm">
              {section.items.map((item, idx) => (
                <button 
                  key={item}
                  className={`w-full px-5 py-4 text-left text-[15px] flex justify-between items-center active:bg-zinc-50 transition-colors ${idx !== section.items.length - 1 ? 'border-b border-zinc-50' : ''}`}
                >
                  <span className="font-medium text-zinc-700">{item}</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-zinc-200" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="px-4 pb-24">
        <button className="w-full py-4 text-red-500 font-semibold bg-red-50 rounded-2xl">
          Log Out
        </button>
      </div>
    </div>
  );
};

const Layout = ({ children, activeView, setView }: { children: React.ReactNode, activeView: View, setView: (v: View) => void }) => {
  return (
    <div className="min-h-screen bg-zinc-50 font-sans text-zinc-900 pb-24">
      <main className="max-w-md mx-auto relative overflow-hidden">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 px-2 pb-8 pt-4 pointer-events-none">
        <div className="max-w-md mx-auto w-full pointer-events-auto">
          <div className="bg-black/90 backdrop-blur-xl rounded-[2.5rem] p-1.5 flex justify-between items-center shadow-2xl">
            <NavItem 
              active={activeView === 'dashboard'} 
              onClick={() => setView('dashboard')}
              icon={<LayoutDashboard size={18} />}
              label="Tasks"
            />
            <NavItem 
              active={activeView === 'calendar'} 
              onClick={() => setView('calendar')}
              icon={<CalendarDays size={18} />}
              label="Events"
            />
            <NavItem 
              active={activeView === 'focus'} 
              onClick={() => setView('focus')}
              icon={<Timer size={18} />}
              label="Focus"
            />
            <NavItem 
              active={activeView === 'notes'} 
              onClick={() => setView('notes')}
              icon={<NotebookTabs size={18} />}
              label="Notes"
            />
            <NavItem 
              active={activeView === 'settings'} 
              onClick={() => setView('settings')}
              icon={<Settings size={18} />}
              label="User"
            />
          </div>
        </div>
      </nav>
    </div>
  );
};

const NavItem = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center justify-center gap-2 px-3 py-3 rounded-[2rem] transition-all duration-300 ${active ? 'bg-white text-black' : 'text-zinc-500 hover:text-white'}`}
    >
      {icon}
      {active && <motion.span initial={{ opacity: 0, x: -5 }} animate={{ opacity: 1, x: 0 }} className="text-[10px] font-bold tracking-tight">{label}</motion.span>}
    </button>
  );
};

// --- Main App ---

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [isTaskCreatorOpen, setIsTaskCreatorOpen] = useState(false);
  const [isEventCreatorOpen, setIsEventCreatorOpen] = useState(false);
  const [isNoteCreatorOpen, setIsNoteCreatorOpen] = useState(false);
  const [todos, setTodos] = useState<Todo[]>([
    { id: '1', text: 'Design the mobile UI', completed: true, important: true, folder: 'Work', tags: ['design', 'ui'] },
    { id: '2', text: 'Implement task filtering', completed: false, important: false, dueDate: 'Today', folder: 'Work', tags: ['dev'] },
    { id: '3', text: 'Plan next week sprints', completed: false, important: true, dueDate: 'Tomorrow', folder: 'Work' },
    { id: '4', text: 'Buy coffee beans', completed: false, important: false, folder: 'Personal', tags: ['shopping'] },
  ]);

  const [events, setEvents] = useState<CalendarEvent[]>([
    { id: '1', title: 'Product Sync', time: '10:00 AM', date: '2026-05-12', type: 'work', tags: ['team', 'planning'] },
    { id: '2', title: 'Lunch with Sarah', time: '1:00 PM', date: '2026-05-12', type: 'social', location: 'Downton Cafe' },
    { id: '3', title: 'Gym Session', time: '5:30 PM', date: '2026-05-12', type: 'personal' },
  ]);

  const [notes, setNotes] = useState<Note[]>([
    { id: '1', title: 'Brainstorming', content: 'New features for the next version: dark mode, cloud sync, collaborations.', updatedAt: '2h ago', tags: ['future'], color: 'bg-amber-50' },
    { id: '2', title: 'Shopping List', content: 'Milk, Eggs, Bread, Avocados, Sparkling water, Coffee.', updatedAt: '5h ago', color: 'bg-emerald-50' },
    { id: '3', title: 'Project Ideas', content: 'A minimalist fitness tracker, a cookbook app for students.', updatedAt: '1d ago', tags: ['side-project'], color: 'bg-blue-50' },
  ]);

  const [selectedDate, setSelectedDate] = useState(new Date());

  const handleCreateTask = (newTask: Partial<Todo>) => {
    const todo: Todo = {
      id: Math.random().toString(36).substr(2, 9),
      text: newTask.text || 'Untitled Task',
      completed: false,
      important: newTask.important || false,
      dueDate: newTask.dueDate || 'Today',
      folder: newTask.folder,
      tags: newTask.tags,
      notes: newTask.notes
    };
    setTodos([todo, ...todos]);
  };

  const handleCreateEvent = (newEvent: Partial<CalendarEvent>) => {
    const event: CalendarEvent = {
      id: Math.random().toString(36).substr(2, 9),
      title: newEvent.title || 'Untitled Event',
      time: newEvent.time || '12:00 PM',
      date: newEvent.date || new Date().toISOString().split('T')[0],
      type: newEvent.type || 'personal',
      location: newEvent.location,
      tags: newEvent.tags,
      notes: newEvent.notes
    };
    // Sort events by time (basic string sort)
    setEvents(prev => [...prev, event].sort((a, b) => a.time.localeCompare(b.time)));
  };

  const handleCreateNote = (newNote: Partial<Note>) => {
    const note: Note = {
      id: Math.random().toString(36).substr(2, 9),
      title: newNote.title || 'Untitled Note',
      content: newNote.content || '',
      updatedAt: 'Just now',
      color: newNote.color,
      tags: newNote.tags
    };
    setNotes([note, ...notes]);
  };

  return (
    <Layout activeView={view} setView={setView}>
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
        >
          {view === 'dashboard' && (
            <Dashboard 
              todos={todos} 
              events={events}
              onOpenCreate={() => setIsTaskCreatorOpen(true)} 
              onOpenEventCreate={() => setIsEventCreatorOpen(true)}
            />
          )}
          {view === 'calendar' && (
            <Calendar 
              events={events} 
              selectedDate={selectedDate}
              setSelectedDate={setSelectedDate}
              onOpenEventCreate={() => setIsEventCreatorOpen(true)} 
            />
          )}
          {view === 'focus' && <FocusTimer />}
          {view === 'notes' && (
            <Notes 
              notes={notes} 
              onOpenCreate={() => setIsNoteCreatorOpen(true)} 
            />
          )}
          {view === 'settings' && <SettingsView />}
        </motion.div>
      </AnimatePresence>

      <CreateTaskModal 
        isOpen={isTaskCreatorOpen} 
        onClose={() => setIsTaskCreatorOpen(false)} 
        onCreate={handleCreateTask}
      />

      <CreateEventModal 
        isOpen={isEventCreatorOpen}
        onClose={() => setIsEventCreatorOpen(false)}
        onCreate={handleCreateEvent}
        initialDate={selectedDate.toISOString().split('T')[0]}
      />

      <CreateNoteModal 
        isOpen={isNoteCreatorOpen}
        onClose={() => setIsNoteCreatorOpen(false)}
        onCreate={handleCreateNote}
      />
    </Layout>
  );
}
